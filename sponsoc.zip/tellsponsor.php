<html>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<LINK REL="STYLESHEET" TYPE="TEXT/CSS" HREF="s.css">
</HEAD>
 <div class="c w3-myfont">
  <a href="wallsociety.php">SPONSOC</a> 
<div class="c1">
</div>
          

</div>
     <div class="w3-row w3-light-grey w3-myfont">
	<div class="w3-bar w3-border w3-light-grey">
           
<a href="wallsponsor.php" class="w3-bar-item w3-button">HOME</a>                           
<a href="event.html" class="w3-bar-item w3-button">Add Event</a>	
<a href="tellsponsor.php" class="w3-bar-item w3-button">Search sponsor</a>	</div>

<h1>THE REGISTERED SPONSORS ARE</h1>
<?php
$servername = "localhost";
$username = "id1070683_userdata";
$password = "userdata";
$db="id1070683_userdata";
// Create connection
$conn = new mysqli($servername, $username, $password, $db);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM sponsor ";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
echo "<br><br>";
        echo "Name of Sponsor:" .$row["fullname"]."<br>";

        echo "Email of Sponsor:" .$row["email"]."<br>";

        echo "Phone number of Sponsor:" .$row["phoneno"]."   <br>";   }
}
?>
</html>