<html>
<body>
<?php
header('Refresh: 5;url=index.html');

$servername = "localhost";
$username = "id1070683_userdata";
$password = "userdata";
$db="id1070683_userdata";
// Create connection
$conn = new mysqli($servername, $username, $password, $db);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$name=$_POST['name'];
$fullname=$_POST['person'];
$college=$_POST['college'];
$fb=$_POST['facebook'];
$ig=$_POST['instagram'];
$twitter=$_POST['twitter'];
$contact=$_POST['contact'];
$email=$_POST['email'];
$pass=$_POST['password'];


$sql = "INSERT INTO society(name,person,college,facebook,instagram,twitter,contact,email,password)
VALUES ('$name','$fullname','$college','$fb','$ig','$twitter','$contact','$email','$pass')";

if($conn->query($sql) === TRUE)
{
echo "You have successfully registered";

}
?>

<br>
<H2><center> "THANK YOU FOR REGISTERING"</center></H2>
</H3><p><center> You will be automatically directed to the login page after 5 seconds...........</center></p></H3>
</body>
</html>