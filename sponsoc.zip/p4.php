<html>
<body>
<?php
header('Refresh: 5;url=examonline.html');

$servername = "localhost";
$username = "id1070683_userdata";
$password = "userdata";
$db="id1070683_userdata";
// Create connection
$conn = new mysqli($servername, $username, $password, $db);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$question1=$_POST['question1'];
$question2=$_POST['question2'];
$question3=$_POST['question3'];
$question4=$_POST['question4'];
global $c;
$c=0;
$sql = "INSERT INTO paper(question1,question1,question1,question1,)
VALUES ('$question1','$question2','$question3','$question4')";
if(strcmp($question1,"Kolkata" ))
$c++;
if(strcmp($question2,"yes"))
$c++;
echo "Your marks are ";
echo $c;
if($conn->query($sql) === TRUE)
{
echo "Your answers have been submitted";
}
?>

<br>
<H2><center> "THANK YOU FOR ANSWERING</center></H2>
</H3><p><center> You will be automatically directed to the login page after 5 seconds...........</center></p></H3>
</body>
</html>