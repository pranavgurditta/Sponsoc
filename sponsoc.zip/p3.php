<?php
$servername = "localhost";
$username = "id1070683_userdata";
$password = "userdata";
$db="id1070683_userdata";

$conn = new mysqli($servername, $username, $password, $db);
echo "you have succesfully logged in ";
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$e=$_POST['username'];
$p=$_POST['password'];
$sql = "SELECT * FROM login WHERE email='$e' AND password='$p'";
header('Refresh: 2; url="p2.html"');

if ($conn->query($sql)) 
{
    echo "Welcome, You have successfully logged in ,wait while you will be  redirected ";
}
?>