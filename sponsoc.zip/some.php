<?php
$servername = "localhost";
$username = "id1070683_userdata";
$password = "userdata";
$db="id1070683_userdata";

// Create connection
$conn = new mysqli($servername, $username, $password, $db);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$em = mysqli_real_escape_string($conn,$_POST['name']);
echo "email is" .$em;

$sql ="INSERT into table_userdata (email) VALUES ('$em')";
if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>