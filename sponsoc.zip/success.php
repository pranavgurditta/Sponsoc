<html>
<body>
<?php
header('Refresh: 5;url=index.html');

$servername = "localhost";
$username = "id1070683_userdata";
$password = "userdata";
$db="id1070683_userdata";
// Create connection
$conn = new mysqli($servername, $username, $password, $db);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sponsor=$_POST['sponsor'];
$fullname=$_POST['fullname'];
$email=$_POST['email'];
$phoneno=$_POST['phoneno'];
$password=$_POST['password'];

if(!empty($_POST['stall']))
{
$stall=$_POST['stall'];
}
else
$stall="";
if(!empty($_POST['gift']))
{
$gift=$_POST['gift'];
}
else
$gift="";
if(!empty($_POST['event']))
{
$event=$_POST['event'];
}
else
$event="";
if(!empty($_POST['seminar']))
{
$seminar=$_POST['seminar'];
}
else
$seminar="";
if(!empty($_POST['refreshment']))
{
$refreshment=$_POST['refreshment'];
}
else
$refreshment="";
if(!empty($_POST['broadcast']))
{
$broadcast=$_POST['broadcast'];
}
else
$broadcast="";
if(!empty($_POST['posters']))
{
$posters=$_POST['posters'];
}
else
$posters="";
if(!empty($_POST['pamphlets']))
{
$pamphlets=$_POST['pamphlets'];
}
else
$pamphlets="";
if(!empty($_POST['app']))
{
$app=$_POST['app'];
}
else
$app="";
if(!empty($_POST['debating']))
{
$debating=$_POST['debating'];
}
else
$debating="";
if(!empty($_POST['management']))
{
$management=$_POST['management'];
}
else
$management="";
if(!empty($_POST['sports']))
{
$sports=$_POST['sports'];
}
else
$sports="";
if(!empty($_POST['food']))
{
$food=$_POST['food'];
}
else
$food="";
if(!empty($_POST['college']))
{
$college=$_POST['college'];
}
else
$college="";
$sql = "INSERT INTO sponsor(sponsor,fullname,email,phoneno,stall,gift,event,seminar,refreshment,broadcast,poster,pamphlet,app,debating,management,sports,food,college,password)
VALUES ('$sponsor','$fullname','$email','$phoneno','$stall','$gift','$event','$seminar','$refreshment','$broadcast','$posters','$pamphlets','$app','$debating','$management','$sports','$food','$college','$password')";

if($conn->query($sql) === TRUE)
{
echo "You have successfully registered";

}

?>
<br>
<H2><center> "THANK YOU FOR REGISTERING"</center></H2>
</H3><p><center> You will be automatically directed to the login page after 5 seconds...........</center></p></H3>
</body>
</html>