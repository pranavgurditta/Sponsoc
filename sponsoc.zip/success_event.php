<html>
<body>
<?php
header('Refresh: 5;url=index.html');

$servername = "localhost";
$username = "id1070683_userdata";
$password = "userdata";
$db="id1070683_userdata";
// Create connection
$conn = new mysqli($servername, $username, $password, $db);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$eventname=$_POST['eventname'];
$societyname=$_POST['societyname'];
$college=$_POST['college'];
$time=$_POST['time'];
$date=$_POST['date'];
$venue=$_POST['venue'];


$sql = "INSERT INTO event(eventname,societyname,college,time,date,venue)
VALUES ('$eventname','$societyname','$college','$time','$date','$venue')";

   
if($conn->query($sql) === TRUE)
{
echo "You have successfully registered";

}
?>

<br>
<H2><center> "THANK YOU FOR REGISTERING"</center></H2>
</H3><p><center> You will be automatically directed to the login page after 5 seconds...........</center></p></H3>
</body>
</html>