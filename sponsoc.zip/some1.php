<?php
$servername = "localhost";
$username = "id1070683_userdata";
$password = "userdata";
$db="id1070683_userdata";

// Create connection
$conn = new mysqli($servername, $username, $password, $db);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$name = mysqli_real_escape_string($conn,$_POST['name']);
$email = mysqli_real_escape_string($conn,$_POST['email']);
$call= mysqli_real_escape_string($conn,$_POST['call']);
$phone= mysqli_real_escape_string($conn,$_POST['phone']);
$budget= mysqli_real_escape_string($conn,$_POST['budget']);
$services= mysqli_real_escape_string($conn,$_POST['services']);

$sql="INSERT INTO sponsor(fullname,email,phoneno,timecall,budget,services) VALUES ('$name','$email','$call','$phone','$budget','$services')";
if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>